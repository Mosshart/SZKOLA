# Unity-Maze-Generator
A Maze Generator I created in Unity. 

It features three different algorithms: Binary Tree, Sidewinder and Recursive Backtracking.

You can find the completed game on my website http://giannis-spentzas.com/MazeGenerator/
